<?php 

require '../config/config.php';
require '../vendor/autoload.php';

//Configuración de errores
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/errors.log');



?>